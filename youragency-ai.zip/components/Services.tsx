import React from 'react';
import { Globe, MessageSquare, Phone, CalendarCheck, CheckCircle2, ArrowRight } from 'lucide-react';
import { ServiceItem } from '../types';

const services: ServiceItem[] = [
  {
    title: "AI Websites",
    description: "Stunning, high-performance websites for portfolios, businesses, and e-commerce.",
    benefits: ["SEO Optimized", "Mobile First Design", "Fast Loading Speed"],
    icon: Globe,
    ctaText: "Get Your Site"
  },
  {
    title: "AI Chatbots",
    description: "24/7 customer support chatbots that answer FAQs and guide visitors to buy.",
    benefits: ["Instant Responses", "Lead Qualification", "Never Sleeps"],
    icon: MessageSquare,
    ctaText: "Automate Chat"
  },
  {
    title: "AI Voice Agents",
    description: "Human-like voice assistants that handle inbound and outbound calls seamlessly.",
    benefits: ["Natural Conversation", "Handles 100+ Calls/min", "Cost Effective"],
    icon: Phone,
    ctaText: "Hear Samples"
  },
  {
    title: "AI Receptionists",
    description: "Complete front-desk automation handling bookings, scheduling, and inquiries.",
    benefits: ["Auto-Scheduling", "CRM Integration", "Professional Tone"],
    icon: CalendarCheck,
    ctaText: "Start Booking"
  }
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-primary-600 font-bold tracking-wide uppercase text-sm mb-3">Our Expertise</h2>
          <h3 className="text-3xl md:text-4xl font-extrabold text-secondary-900">Everything You Need to Scale</h3>
          <p className="mt-4 text-xl text-slate-600 max-w-2xl mx-auto">Stop trading time for money. Let our AI solutions handle the repetitive tasks so you can focus on growth.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="group relative bg-slate-50 rounded-2xl p-8 border border-slate-100 hover:border-primary-100 hover:shadow-xl hover:shadow-primary-900/5 transition-all duration-300">
              <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                <service.icon size={80} className="text-primary-600" />
              </div>
              
              <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center text-primary-600 shadow-sm mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon size={28} />
              </div>
              
              <h4 className="text-xl font-bold text-secondary-900 mb-3">{service.title}</h4>
              <p className="text-slate-600 mb-6 leading-relaxed text-sm h-20">{service.description}</p>
              
              <ul className="space-y-3 mb-8">
                {service.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-center text-sm text-slate-700 font-medium">
                    <CheckCircle2 size={16} className="text-green-500 mr-2 flex-shrink-0" />
                    {benefit}
                  </li>
                ))}
              </ul>
              
              <a href="#contact" className="inline-flex items-center text-primary-700 font-bold hover:gap-2 transition-all group-hover:text-primary-600">
                {service.ctaText} <ArrowRight size={18} className="ml-1" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;