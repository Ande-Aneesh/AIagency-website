import React from 'react';
import { Star } from 'lucide-react';
import { TestimonialItem } from '../types';

const testimonials: TestimonialItem[] = [
  {
    name: "Alex Johnson",
    role: "Founder",
    company: "TechStart Inc.",
    content: "The AI Voice Agent they built handles 80% of our inbound calls now. It's saving us roughly $2k/month on support staff.",
    image: "https://picsum.photos/id/1005/100/100"
  },
  {
    name: "Priya Sharma",
    role: "Owner",
    company: "Urban Eatery",
    content: "Our table bookings increased by 40% after installing the website chatbot. It works flawlessly even at 2 AM.",
    image: "https://picsum.photos/id/338/100/100"
  },
  {
    name: "David Chen",
    role: "CEO",
    company: "Growth Marketing",
    content: "Incredible speed. They launched our entire agency site in 5 days. The design is top-tier and the price was unbeatable.",
    image: "https://picsum.photos/id/64/100/100"
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-24 bg-secondary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold">What Our Clients Say</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((item, idx) => (
            <div key={idx} className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700 backdrop-blur-sm">
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-slate-300 italic mb-6 leading-relaxed">"{item.content}"</p>
              <div className="flex items-center gap-4">
                <img src={item.image} alt={item.name} className="w-12 h-12 rounded-full object-cover border-2 border-primary-500" />
                <div>
                  <h4 className="font-bold">{item.name}</h4>
                  <p className="text-sm text-slate-400">{item.role}, {item.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;