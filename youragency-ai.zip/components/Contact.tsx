import React, { useState, useRef, useEffect } from 'react';
import { Send, CheckCircle, MessageSquare, X, Bot, Sparkles } from 'lucide-react';

const Contact: React.FC = () => {
  // --- Contact Form State ---
  const [formState, setFormState] = useState({ name: '', email: '', service: 'consultation', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setTimeout(() => setIsSubmitted(true), 1000);
  };

  // --- Chat Widget State ---
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{role: 'user' | 'ai', text: string}>>([
    { role: 'ai', text: "Hello! 👋 I'm the agency's AI assistant. Are you looking to automate your business?" }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (isChatOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isChatOpen, isAiTyping]);

  const handleChatSend = (text: string = chatInput) => {
    if (!text.trim()) return;

    // User Message
    setMessages(prev => [...prev, { role: 'user', text }]);
    setChatInput("");
    setIsAiTyping(true);

    // AI Response Simulation
    setTimeout(() => {
      let response = "That sounds interesting! The best next step is to fill out the form so our human experts can give you a demo.";
      const lower = text.toLowerCase();
      
      if (lower.includes('price') || lower.includes('cost') || lower.includes('much')) {
        response = "Our AI websites start at ₹5,000 ($300). For custom AI agents, we provide tailored quotes. Would you like a price list?";
      } else if (lower.includes('website')) {
        response = "We can build a fully automated, high-conversion website for you in just 5-7 days.";
      } else if (lower.includes('demo') || lower.includes('book')) {
        response = "Great! You can book a free demo using the form on this page. We'll show you the AI in action.";
      } else if (lower.includes('chat') || lower.includes('bot')) {
        response = "Our chatbots work 24/7 to capture leads and support customers. This chat widget is actually a simple demo of what we can build!";
      } else if (lower.includes('yes') || lower.includes('sure')) {
        response = "Awesome. What specific service are you most interested in right now?";
      }

      setMessages(prev => [...prev, { role: 'ai', text: response }]);
      setIsAiTyping(false);
    }, 1200);
  };

  return (
    <section id="contact" className="py-24 bg-secondary-900 text-white relative">
      <div className="absolute inset-0 bg-gradient-to-br from-secondary-900 to-slate-900"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row">
          
          {/* Info Side */}
          <div className="bg-primary-600 p-10 md:w-2/5 text-white flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-4">Let's Automate Your Business</h3>
              <p className="text-primary-100 mb-8 leading-relaxed">Fill out the form and we'll get back to you within 24 hours to schedule your free demo.</p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center font-bold">E</div>
                  <span>hello@youragency.ai</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center font-bold">P</div>
                  <span>+1 (555) 123-4567</span>
                </div>
              </div>
            </div>
            
            <div className="mt-10">
               <p className="text-sm text-primary-200">"The best investment we made this year." - Startup Founder</p>
            </div>
          </div>

          {/* Form Side */}
          <div className="p-10 md:w-3/5 bg-white text-slate-900">
            {isSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={32} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Message Sent!</h3>
                <p className="text-slate-500">Thanks for reaching out, {formState.name}. We'll be in touch shortly.</p>
                <button 
                  onClick={() => setIsSubmitted(false)}
                  className="mt-8 text-primary-600 font-bold hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-bold text-slate-700 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    id="name"
                    required
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                    placeholder="John Doe"
                    value={formState.name}
                    onChange={(e) => setFormState({...formState, name: e.target.value})}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-bold text-slate-700 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    id="email"
                    required
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                    placeholder="john@company.com"
                    value={formState.email}
                    onChange={(e) => setFormState({...formState, email: e.target.value})}
                  />
                </div>
                <div>
                  <label htmlFor="service" className="block text-sm font-bold text-slate-700 mb-1">Interested Service</label>
                  <select 
                    id="service"
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all bg-white"
                    value={formState.service}
                    onChange={(e) => setFormState({...formState, service: e.target.value})}
                  >
                    <option value="consultation">General Consultation</option>
                    <option value="website">AI Website</option>
                    <option value="chatbot">AI Chatbot</option>
                    <option value="voice_agent">Voice Agent</option>
                    <option value="receptionist">AI Receptionist</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-bold text-slate-700 mb-1">Project Details</label>
                  <textarea 
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all resize-none"
                    placeholder="Tell us about your business and goals..."
                    value={formState.message}
                    onChange={(e) => setFormState({...formState, message: e.target.value})}
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  className="w-full py-4 bg-secondary-900 text-white rounded-lg font-bold hover:bg-slate-800 transition-colors shadow-lg flex items-center justify-center gap-2"
                >
                  Book Free Demo <Send size={18} />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* --- Live Chat Widget --- */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
        <div className="pointer-events-auto flex flex-col items-end">
          {/* Chat Window */}
          {isChatOpen && (
              <div className="mb-4 w-[90vw] md:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-fade-in-up flex flex-col h-[500px] max-h-[70vh]">
                  {/* Header */}
                  <div className="bg-slate-900 p-4 flex justify-between items-center text-white">
                    <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center">
                            <Bot size={20} />
                          </div>
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
                        </div>
                        <div>
                          <div className="flex items-center gap-1">
                            <h4 className="font-bold text-sm">Agency Assistant</h4>
                            <Sparkles size={12} className="text-yellow-400" />
                          </div>
                          <p className="text-xs text-slate-400">Online | Replies in 1s</p>
                        </div>
                    </div>
                    <button onClick={() => setIsChatOpen(false)} className="text-slate-400 hover:text-white transition-colors"><X size={20}/></button>
                  </div>
                  
                  {/* Messages Area */}
                  <div className="flex-1 p-4 bg-slate-50 overflow-y-auto">
                    {messages.map((m, i) => (
                        <div key={i} className={`flex mb-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-primary-600 text-white rounded-br-none' : 'bg-white text-slate-800 shadow-sm border border-slate-100 rounded-bl-none'}`}>
                              {m.text}
                          </div>
                        </div>
                    ))}
                    {isAiTyping && (
                        <div className="flex justify-start mb-3">
                          <div className="bg-white p-3 rounded-2xl rounded-bl-none shadow-sm border border-slate-100 flex gap-1">
                            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-75"></span>
                            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-150"></span>
                          </div>
                        </div>
                    )}
                    <div ref={chatEndRef}></div>
                  </div>

                  {/* Quick Replies */}
                  <div className="px-4 py-2 bg-slate-50 flex gap-2 overflow-x-auto no-scrollbar border-t border-slate-100">
                      {['Pricing?', 'Book Demo', 'Services'].map(opt => (
                          <button 
                            key={opt} 
                            onClick={() => handleChatSend(opt)} 
                            className="whitespace-nowrap px-3 py-1.5 bg-white border border-slate-200 text-slate-600 text-xs font-medium rounded-full hover:bg-primary-50 hover:border-primary-200 hover:text-primary-600 transition-colors shadow-sm"
                          >
                            {opt}
                          </button>
                      ))}
                  </div>

                  {/* Input Area */}
                  <div className="p-3 bg-white border-t border-slate-100">
                    <form onSubmit={(e) => { e.preventDefault(); handleChatSend(); }} className="flex gap-2">
                        <input 
                          className="flex-1 bg-slate-100 border-0 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary-500 outline-none transition-all placeholder:text-slate-400"
                          placeholder="Ask anything..."
                          value={chatInput}
                          onChange={e => setChatInput(e.target.value)}
                        />
                        <button 
                          type="submit" 
                          disabled={!chatInput.trim()}
                          className="p-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <Send size={18} />
                        </button>
                    </form>
                  </div>
              </div>
          )}

          {/* Toggle Button */}
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="group relative w-14 h-14 bg-primary-600 text-white rounded-full shadow-lg shadow-primary-600/30 flex items-center justify-center hover:scale-110 transition-all hover:bg-primary-700"
          >
            {isChatOpen ? <X size={28} /> : <MessageSquare size={28} />}
            
            {/* Notification Badge */}
            {!isChatOpen && (
              <span className="absolute top-0 right-0 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 border-2 border-white"></span>
              </span>
            )}
          </button>
        </div>
      </div>

    </section>
  );
};

export default Contact;