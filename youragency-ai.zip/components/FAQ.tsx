import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  { question: "Is this real AI or just scripted responses?", answer: "We use advanced LLMs (like GPT-4 and Gemini) for dynamic, intelligent conversations. However, we can also build scripted flows if you prefer strict control over the output." },
  { question: "Can the voice agent really handle bookings?", answer: "Yes! Our voice agents can integrate with your calendar (Google, Calendly, etc.) to check availability and book slots in real-time." },
  { question: "How fast can you launch my project?", answer: "For standard AI websites and simple chatbots, we typically launch within 5-7 business days after receiving your requirements." },
  { question: "Do you support clients outside of India?", answer: "Absolutely. We work with clients globally, primarily in the US, UK, and Canada. We handle payments via Stripe or Wise." },
  { question: "Is the AI customizable to my brand voice?", answer: "Yes. We 'train' the AI on your specific business data, tone guidelines, and FAQs to ensure it sounds exactly like your brand." }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold text-secondary-900">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="border border-slate-200 rounded-xl overflow-hidden">
              <button 
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full flex justify-between items-center p-5 text-left bg-slate-50 hover:bg-slate-100 transition-colors"
              >
                <span className="font-bold text-slate-800">{faq.question}</span>
                {openIndex === idx ? <ChevronUp className="text-primary-600" /> : <ChevronDown className="text-slate-400" />}
              </button>
              <div className={`transition-all duration-300 ease-in-out ${openIndex === idx ? 'max-h-48 opacity-100 p-5' : 'max-h-0 opacity-0 p-0 overflow-hidden'}`}>
                <p className="text-slate-600 leading-relaxed">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;