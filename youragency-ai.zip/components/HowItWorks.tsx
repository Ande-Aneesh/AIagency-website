import React from 'react';

const steps = [
  {
    num: "01",
    title: "Book a Free Demo",
    desc: "Schedule a 15-minute call. We'll analyze your business needs and show you exactly how AI can help."
  },
  {
    num: "02",
    title: "We Build Your Solution",
    desc: "Our team customizes the AI, trains the chatbots/agents on your data, and designs your site."
  },
  {
    num: "03",
    title: "Launch in 5-7 Days",
    desc: "We deploy everything live. No long waiting periods. You start capturing leads immediately."
  },
  {
    num: "04",
    title: "Support & Optimization",
    desc: "We monitor performance, update the AI, and ensure everything runs smoothly 24/7."
  }
];

const HowItWorks: React.FC = () => {
  return (
    <section id="process" className="py-24 bg-secondary-900 text-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 pointer-events-none">
         <div className="absolute top-1/4 -left-10 w-96 h-96 bg-primary-600 rounded-full blur-3xl mix-blend-screen"></div>
         <div className="absolute bottom-1/4 -right-10 w-96 h-96 bg-purple-600 rounded-full blur-3xl mix-blend-screen"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-primary-400 font-bold tracking-wide uppercase text-sm mb-3">Simple Process</h2>
          <h3 className="text-3xl md:text-4xl font-extrabold text-white">From Idea to Automation in 1 Week</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
           {/* Connecting Line (Desktop) */}
           <div className="hidden lg:block absolute top-12 left-0 w-full h-0.5 bg-slate-700 -z-10"></div>

          {steps.map((step, index) => (
            <div key={index} className="relative bg-secondary-900/50 backdrop-blur-sm p-6 rounded-2xl border border-slate-800 hover:border-primary-500 transition-colors">
              <div className="w-12 h-12 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold text-xl mb-6 shadow-lg shadow-primary-900/50 mx-auto lg:mx-0 relative z-10">
                {step.num}
              </div>
              <h4 className="text-xl font-bold mb-3 text-white text-center lg:text-left">{step.title}</h4>
              <p className="text-slate-400 leading-relaxed text-center lg:text-left">{step.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a href="#contact" className="inline-block px-10 py-4 bg-white text-secondary-900 font-bold rounded-full hover:bg-slate-100 transition-transform hover:scale-105 shadow-xl">
            Start Your Journey
          </a>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;