import React, { useState } from 'react';
import { Check, X } from 'lucide-react';
import { Region } from '../types';

const Pricing: React.FC = () => {
  const [region, setRegion] = useState<Region>(Region.INDIA);

  const formatPrice = (priceIn: string, priceIntl: string) => {
    return region === Region.INDIA ? `₹${priceIn}` : `$${priceIntl}`;
  };

  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold text-secondary-900">Simple, Transparent Pricing</h2>
          <p className="mt-4 text-slate-600">Choose the package that fits your stage of growth.</p>
          
          {/* Toggle Switch */}
          <div className="mt-8 flex justify-center items-center gap-4">
            <span className={`text-sm font-bold ${region === Region.INDIA ? 'text-primary-600' : 'text-slate-400'}`}>India (INR)</span>
            <button 
              onClick={() => setRegion(region === Region.INDIA ? Region.INTL : Region.INDIA)}
              className="relative w-14 h-8 bg-slate-200 rounded-full transition-colors focus:outline-none"
            >
              <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 ${region === Region.INTL ? 'translate-x-6' : ''}`}></div>
            </button>
            <span className={`text-sm font-bold ${region === Region.INTL ? 'text-primary-600' : 'text-slate-400'}`}>International (USD)</span>
          </div>
        </div>

        {/* AI Websites Pricing */}
        <h3 className="text-xl font-bold text-slate-800 mb-6 border-l-4 border-primary-600 pl-4">AI Website Packages</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {[
            { name: 'Landing Page', priceIN: '5,000', priceINTL: '300-500', features: ['One Page Design', 'Mobile Responsive', 'Contact Form'] },
            { name: 'Portfolio', priceIN: '8,000', priceINTL: '600-900', features: ['Up to 3 Pages', 'Gallery/Showcase', 'Social Integration'] },
            { name: 'Business', priceIN: '12,000', priceINTL: '800-1,500', features: ['Up to 5 Pages', 'Blog Section', 'SEO Basic Setup'], highlight: true },
            { name: 'E-commerce', priceIN: '20,000+', priceINTL: '1,500-3,000+', features: ['Product Catalog', 'Payment Gateway', 'Cart System'] }
          ].map((tier, idx) => (
            <div key={idx} className={`p-6 rounded-2xl border ${tier.highlight ? 'border-primary-500 shadow-xl scale-105 bg-white z-10' : 'border-slate-200 bg-slate-50'} flex flex-col`}>
              {tier.highlight && <div className="bg-primary-600 text-white text-xs font-bold px-3 py-1 rounded-full w-fit mb-4">Most Popular</div>}
              <h4 className="text-lg font-bold text-slate-900">{tier.name}</h4>
              <div className="mt-4 mb-6">
                <span className="text-3xl font-extrabold text-slate-900">{formatPrice(tier.priceIN, tier.priceINTL)}</span>
                <span className="text-slate-500 text-sm"> / one-time</span>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                {tier.features.map((f, i) => (
                  <li key={i} className="flex items-center text-sm text-slate-600">
                    <Check size={16} className="text-green-500 mr-2" /> {f}
                  </li>
                ))}
              </ul>
              <a href="#contact" className={`block w-full py-3 text-center rounded-lg font-bold transition-colors ${tier.highlight ? 'bg-primary-600 text-white hover:bg-primary-700' : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50'}`}>
                Get Started
              </a>
            </div>
          ))}
        </div>

        {/* AI Services Pricing */}
        <h3 className="text-xl font-bold text-slate-800 mb-6 border-l-4 border-purple-600 pl-4">AI Automation Services</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="bg-slate-900 text-white p-8 rounded-2xl col-span-1 md:col-span-3 lg:col-span-3 flex flex-col md:flex-row justify-between items-center gap-8">
              <div>
                <h4 className="text-2xl font-bold mb-2">Chatbots, Voice Agents & Receptionists</h4>
                <p className="text-slate-300">Custom tailored solutions for your specific business logic and workflows.</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-extrabold text-primary-400">Custom Quote</div>
                <div className="text-sm text-slate-400 mt-1">Based on complexity & usage</div>
              </div>
              <a href="#contact" className="bg-white text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-slate-100 transition-colors whitespace-nowrap">
                Request Quote
              </a>
           </div>
        </div>

        <div className="mt-12 text-center text-sm text-slate-500 bg-slate-50 p-4 rounded-lg inline-block w-full">
           <span className="font-bold">Monthly Maintenance & Support:</span> {formatPrice('3,000', '150-300')} / month. Includes hosting, updates, and 24/7 monitoring.
        </div>

      </div>
    </section>
  );
};

export default Pricing;