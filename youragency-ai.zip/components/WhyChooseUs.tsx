import React from 'react';
import { Clock, Globe, Wallet, Zap, Code2, MessagesSquare } from 'lucide-react';

const reasons = [
  { icon: Clock, title: "Lightning Fast", desc: "We launch standard projects in 5-7 days, not months." },
  { icon: Wallet, title: "Startup Friendly", desc: "Affordable pricing significantly lower than US-based agencies." },
  { icon: Globe, title: "Global Standard", desc: "We work with clients from India, US, UK, and Dubai." },
  { icon: Zap, title: "Modern Tech Stack", desc: "We use the latest AI models (Gemini, GPT-4) and frameworks." },
  { icon: MessagesSquare, title: "Clear Communication", desc: "Native English proficiency for smooth collaboration." },
  { icon: Code2, title: "Custom Solutions", desc: "We don't just use templates; we build what you need." },
];

const WhyChooseUs: React.FC = () => {
  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold text-secondary-900">Why Partner With Us?</h2>
          <p className="mt-4 text-slate-600 max-w-2xl mx-auto">We combine technical expertise with business strategy to deliver results.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((item, idx) => (
            <div key={idx} className="bg-white p-8 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center text-primary-600 mb-6">
                <item.icon size={24} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
              <p className="text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;