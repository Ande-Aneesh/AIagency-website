import React from 'react';
import { ArrowRight, PlayCircle } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full z-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary-200/40 rounded-full blur-3xl mix-blend-multiply animate-pulse"></div>
        <div className="absolute top-40 right-10 w-96 h-96 bg-purple-200/40 rounded-full blur-3xl mix-blend-multiply"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold uppercase tracking-wide mb-8 animate-fade-in-up">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          Accepting New Clients for 2025
        </div>
        
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-secondary-900 tracking-tight mb-6 leading-tight">
          AI Websites & Voice Agents <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-purple-600">
            That Work While You Sleep
          </span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-slate-600 mb-10 leading-relaxed">
          We build fully automated websites, intelligent chatbots, and human-like voice agents for startups and small businesses worldwide. Save time, capture more leads, and never miss a customer.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <a 
            href="#contact" 
            className="w-full sm:w-auto px-8 py-4 bg-secondary-900 text-white rounded-xl font-bold text-lg hover:bg-slate-800 transition-all transform hover:-translate-y-1 shadow-xl shadow-slate-900/20 flex items-center justify-center gap-2"
          >
            Book a Free Demo <ArrowRight size={20} />
          </a>
          <a 
            href="#services" 
            className="w-full sm:w-auto px-8 py-4 bg-white text-secondary-900 border border-slate-200 rounded-xl font-bold text-lg hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            View Services
          </a>
        </div>

        <div className="mt-16 flex flex-col items-center">
          <p className="text-sm text-slate-500 mb-4 font-medium">Trusted by founders globally</p>
          <div className="flex flex-wrap justify-center gap-8 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
             {/* Placeholder Logos */}
             <div className="h-8 w-24 bg-slate-300 rounded animate-pulse"></div>
             <div className="h-8 w-28 bg-slate-300 rounded animate-pulse delay-75"></div>
             <div className="h-8 w-20 bg-slate-300 rounded animate-pulse delay-150"></div>
             <div className="h-8 w-32 bg-slate-300 rounded animate-pulse delay-100"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;