import React, { useState, useEffect, useRef } from 'react';
import { Bot, User, Send, Mic, RefreshCw } from 'lucide-react';

interface Message {
  role: 'ai' | 'user';
  text: string;
}

const DemoSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'voice'>('chat');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', text: "Hello! I'm your AI Receptionist. How can I help your business today?" }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [demoStep, setDemoStep] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const chatScript = [
    { user: "I want to book a consultation.", ai: "That's great! I can help you with that. What day works best for you?" },
    { user: "How about next Tuesday morning?", ai: "Let me check... Yes, we have an opening at 10:00 AM on Tuesday. Shall I book that for you?" },
    { user: "Yes, please.", ai: "Perfect! You are booked for Tuesday at 10:00 AM. I've sent a calendar invite to your email. Anything else?" },
    { user: "No, that's all. Thanks!", ai: "You're welcome! Have a wonderful day." }
  ];

  const handleSimulate = () => {
    if (demoStep >= chatScript.length || isTyping) return;

    // User Message
    const currentTurn = chatScript[demoStep];
    const userMsg = { role: 'user', text: currentTurn.user } as Message;
    
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    // AI Response Delay
    setTimeout(() => {
      setIsTyping(false);
      const aiMsg = { role: 'ai', text: currentTurn.ai } as Message;
      setMessages(prev => [...prev, aiMsg]);
      setDemoStep(prev => prev + 1);
    }, 1500);
  };

  const resetDemo = () => {
    setMessages([{ role: 'ai', text: "Hello! I'm your AI Receptionist. How can I help your business today?" }]);
    setDemoStep(0);
    setIsTyping(false);
  };

  return (
    <section id="demo" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Content */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-bold uppercase mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              Live Simulation
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold text-secondary-900 mb-6">
              Experience the Power of <br />
              <span className="text-primary-600">AI Interactions</span>
            </h2>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Our AI agents are trained to handle complex conversations, book appointments, and capture leads 24/7.
              <br /><br />
              Try the simulation to see how an AI Receptionist handles a booking request in real-time.
            </p>
            
            <div className="flex flex-col gap-4">
              <div className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm border border-slate-100">
                <div className="p-3 bg-primary-50 rounded-lg text-primary-600">
                  <Bot size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">Instant Lead Capture</h4>
                  <p className="text-sm text-slate-500 mt-1">Engage visitors immediately, even when you're asleep.</p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm border border-slate-100">
                <div className="p-3 bg-purple-50 rounded-lg text-purple-600">
                  <Mic size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">Human-like Voice</h4>
                  <p className="text-sm text-slate-500 mt-1">Natural pausing and intonation that feels like a real person.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Demo UI */}
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-primary-600 to-purple-600 rounded-2xl blur-lg opacity-20"></div>
            <div className="relative bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200">
              
              {/* Header */}
              <div className="bg-slate-900 p-4 flex justify-between items-center text-white">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center">
                      <Bot size={20} />
                    </div>
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Sarah - AI Receptionist</h3>
                    <p className="text-xs text-slate-400">Online | Replies instantly</p>
                  </div>
                </div>
                <button 
                   onClick={resetDemo} 
                   className="p-2 hover:bg-slate-700 rounded-full transition-colors text-slate-400 hover:text-white"
                   title="Reset Demo"
                >
                  <RefreshCw size={18} />
                </button>
              </div>

              {/* Chat Area */}
              <div className="h-80 bg-slate-50 p-4 overflow-y-auto">
                <div className="space-y-4">
                  {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-primary-600 text-white rounded-br-none' 
                          : 'bg-white text-slate-800 shadow-sm border border-slate-100 rounded-bl-none'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white p-4 rounded-2xl rounded-bl-none shadow-sm border border-slate-100 flex gap-1">
                        <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75"></span>
                        <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150"></span>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Controls */}
              <div className="p-4 bg-white border-t border-slate-100">
                {demoStep < chatScript.length ? (
                  <button 
                    onClick={handleSimulate}
                    disabled={isTyping}
                    className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 group disabled:opacity-50"
                  >
                    {isTyping ? 'AI is replying...' : `Simulate User: "${chatScript[demoStep].user}"`}
                    {!isTyping && <Send size={16} className="group-hover:translate-x-1 transition-transform"/>}
                  </button>
                ) : (
                  <button 
                    onClick={resetDemo}
                    className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors"
                  >
                    Start New Conversation
                  </button>
                )}
                <p className="text-center text-xs text-slate-400 mt-3">
                  * This is a simulation. Actual AI responses may vary based on your custom training.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoSection;